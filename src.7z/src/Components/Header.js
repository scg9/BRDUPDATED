import react from 'react';
const Header=()=>{
    return(
    <header>
    <h1>ABSLI BRD Automation</h1>
    <h2>Please enter the required text</h2>
  </header>
    );
}
export default Header