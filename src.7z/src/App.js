import './App.css';
import Header from './Components/Header';
import Inputtext from './Components/InputText';

function App() {
  return (
    <div className="App">
     <Header/>
     <Inputtext/>
    </div>
  );
}

export default App;
